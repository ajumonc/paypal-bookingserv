package com.paypal.bfs.test.bookingserv.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The DAO entity for CRUD
 */
@Entity
@Table
public class BOOKINGTABLE {
    @Id
    @Column
    private int id;
    @Column
    private  String first_name;
    @Column
    private String last_name;
    @Column
    private  String date_of_birth;
    @Column
    private String checkin_datetime;
    @Column
    private String checkout_datetime;
    @Column
    private  double total_price;
    @Column
    private  double deposit;
    @ Column
    private  String address;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public String getCheckin_datetime() {
        return checkin_datetime;
    }

    public void setCheckin_datetime(String checkin_datetime) {
        this.checkin_datetime = checkin_datetime;
    }

    public String getCheckout_datetime() {
        return checkout_datetime;
    }

    public void setCheckout_datetime(String checkout_datetime) {
        this.checkout_datetime = checkout_datetime;
    }

    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
