package com.paypal.bfs.test.bookingserv.service;

import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.paypal.bfs.test.bookingserv.model.BOOKINGTABLE;
import com.paypal.bfs.test.bookingserv.util.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Service
public class BookingService {
    private static final Logger log = LoggerFactory.getLogger(BookingService.class);
    @Autowired
    BookingRepository repository;

    /**To Create the booking
     * @param bookingDTO
     * @return
     * @throws SQLException
     */
    //- to ensure the idempotency
    @Transactional(isolation = Isolation.SERIALIZABLE)
    public ResponseEntity<Booking> create(Booking bookingDTO) throws SQLException {
        BOOKINGTABLE bookingtable = new BOOKINGTABLE();
        bookingtable.setId(bookingDTO.getId());
        bookingtable.setFirst_name(bookingDTO.getFirstName());
        bookingtable.setLast_name(bookingDTO.getLastName());
        bookingtable.setDeposit(bookingDTO.getDeposit());
        bookingtable.setTotal_price(bookingDTO.getTotalPrice());
        bookingtable.setCheckin_datetime(bookingDTO.getCheckinDatetime());
        bookingtable.setCheckout_datetime(bookingDTO.getCheckoutDatetime());
        bookingtable.setDate_of_birth(bookingDTO.getDateOfBirth());
        StringBuilder addressBuilder = new StringBuilder();
        addressBuilder.append(bookingDTO.getAddress());
        bookingtable.setAddress(addressBuilder.toString());
        log.info("Booking Details",bookingtable);

        repository.save(bookingtable);
        return new ResponseEntity<Booking>(bookingDTO,HttpStatus.OK);
    }

    /**To retrieve the records
     * @return
     * @throws SQLException
     */
    public ResponseEntity<List<Booking>> retrieve() throws  SQLException {

            List<BOOKINGTABLE> bookingsDAO = new ArrayList<BOOKINGTABLE>();
            repository.findAll().forEach(booking -> bookingsDAO.add(booking));
            List<Booking> bookingList= new ArrayList<Booking>();
            bookingsDAO.forEach(bookingDAO->{
                Booking bookingRow = new Booking();
                bookingRow.setId(bookingDAO.getId());
                bookingRow.setFirstName(bookingDAO.getFirst_name());
                bookingRow.setLastName(bookingDAO.getLast_name());
                bookingRow.setDeposit(bookingDAO.getDeposit());
                bookingRow.setTotalPrice(bookingDAO.getTotal_price());
                bookingRow.setDateOfBirth(bookingDAO.getDate_of_birth());
                bookingRow.setCheckinDatetime(bookingDAO.getCheckin_datetime());
                bookingRow.setCheckoutDatetime(bookingDAO.getCheckout_datetime());
                bookingRow.setAddress(bookingDAO.getAddress());
                bookingList.add(bookingRow);

            });
            log.info("Retrieved data",bookingList);
            return new ResponseEntity<List<Booking>>(bookingList, HttpStatus.OK);

    }

}
