package com.paypal.bfs.test.bookingserv.impl;

import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class BookingResourceImpl implements BookingResource {
    private static final Logger log = LoggerFactory.getLogger(BookingResourceImpl.class);
    @Autowired
    BookingService service;

    /**Implementation for create service
     * If there is any error it will return internal server error otherwise ok
     * @param booking the booking object
     * @return
     */
    @Override
    public ResponseEntity<Booking> create(Booking booking)  {
        try {
            return service.create(booking);
        } catch (Exception error) {
            log.error("Creation error"+error);
            return new ResponseEntity<Booking>(booking, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**Implemetation for the retrieval service
     * If there is any error it will return internal server error otherwise ok
     * @return
     */
    @Override
    public ResponseEntity<List<Booking>> retrieve(){
        try {
            return service.retrieve();
        } catch (Exception error) {
            log.error("Retrieval error"+error);
            List<Booking> bookingList= new ArrayList();
            return new ResponseEntity<List<Booking>>(bookingList, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
