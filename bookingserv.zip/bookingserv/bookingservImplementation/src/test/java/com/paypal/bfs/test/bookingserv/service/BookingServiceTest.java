package com.paypal.bfs.test.bookingserv.service;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.paypal.bfs.test.bookingserv.api.model.*;

import java.sql.SQLException;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
class BookingServiceTest {
    @InjectMocks
    BookingService bookingService= new BookingService();
    @Rule
    public MockitoRule initRule = MockitoJUnit.rule();
    @BeforeEach
    void init()
        {
            MockitoAnnotations.initMocks(this);
    }
    @Test
    void create()throws Exception {
       Booking booking= new Booking();
       booking.setFirstName("pay");
       booking.setLastName("pay");
       booking.setId(123);
       ResponseEntity entity=bookingService.create(booking);
       Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
        }

    @Test
    void retrieve() throws Exception {
            ResponseEntity<List<Booking>> entity=bookingService.retrieve();
            Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
        }

}