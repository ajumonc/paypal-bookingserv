package com.paypal.bfs.test.bookingserv.impl;

import com.paypal.bfs.test.bookingserv.service.BookingService;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.paypal.bfs.test.bookingserv.api.model.Booking;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@RunWith(MockitoJUnitRunner.class)
class BookingResourceImplTest {
    @Mock
    BookingService service;
    @InjectMocks
    BookingResourceImpl resource= new BookingResourceImpl();
    @Rule
    public MockitoRule initRule = MockitoJUnit.rule();
    @BeforeEach
    void init()
    {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void create() {
        Booking booking= new Booking();
        booking.setFirstName("pay");
        booking.setLastName("pay");
        booking.setId(123);
        Mockito.when(service.create(Mockito.any())).getMock();
        ResponseEntity entity=resource.create(booking);
        assertEquals(entity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    void retrieve() {
        ResponseEntity<List<Booking>> entity=resource.retrieve();
        Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
    }
}